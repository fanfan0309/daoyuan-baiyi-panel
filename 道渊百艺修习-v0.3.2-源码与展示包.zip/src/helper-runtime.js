// Source template for a character-local Tavern Helper script.
// tools/build.mjs replaces the one HTML marker with the JSON-escaped panel asset.
const PANEL_HTML = __PANEL_HTML_JSON__;

const MODULE_KEY = 'daoyuan_baiyi_v1';
const PENDING_KEY = 'daoyuan_baiyi_pending';
const UI_KEY = 'daoyuan_baiyi_ui';
const BUTTON_NAME = '百艺面板';
const MODULE_TAG = 'baiyi_update';
const MAX_ORDERS = 80;
const ALL_PROFESSIONS = ['炼丹', '炼器', '制符', '布阵', '灵植', '御兽', '傀儡', '医修', '灵食'];
const OWNED_PROFESSIONS = ['制符', '布阵', '灵植', '御兽', '傀儡', '医修', '灵食'];
const ALLOWED_ORDER_STATES = ['待接取', '进行中', '待交付', '已完成', '已失败', '已放弃', '已拒绝'];

const api = new Proxy({}, { get: (_target, key) => globalThis.TavernHelper?.[key] ?? globalThis[key] });

function requireCapabilities() {
  const required = ['eventOn', 'getButtonEvent', 'getVariables', 'insertVariables', 'insertOrAssignVariables', 'deleteVariable', 'createChatMessages', 'getChatMessages', 'getLastMessageId', 'setChatMessages', 'triggerSlash'];
  return required.filter(name => typeof api[name] !== 'function');
}

function defaultState() {
  return {
    schemaVersion: 4,
    revision: 0,
    艺业: Object.fromEntries(OWNED_PROFESSIONS.map(name => [name, {阶级: '未入门', 熟练度: 0, 成功率: 0, 次数: 0, 技法: []}])),
    委托: [],
    履历: [],
    器灵档案: [],
    器灵尝试: [],
  };
}

function text(value, max = 120) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

function textList(value, limit = 12, max = 100) {
  if (!Array.isArray(value)) return [];
  return value.slice(0, limit).map(item => text(item, max)).filter(Boolean);
}

function validTextList(value, limit, max) {
  return value === undefined || (Array.isArray(value) && value.length <= limit && value.every(item => typeof item === 'string' && item.length <= max));
}

function normalizeRank(value) {
  const rank = text(value, 24) || '未入门';
  const legacy = {'初阶':'一阶','初窥':'一阶','熟手':'二阶','精进':'三阶','专精':'四阶'};
  return legacy[rank] ?? rank;
}

function cleanState(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || ![1,2,3,4].includes(value.schemaVersion)) return null;
  if (!Number.isInteger(value.revision) || value.revision < 0) return null;
  if (!value.艺业 || typeof value.艺业 !== 'object' || Array.isArray(value.艺业)) return null;
  const skills = {};
  for (const name of OWNED_PROFESSIONS) {
    const hasSkill = Object.prototype.hasOwnProperty.call(value.艺业, name);
    const row = !hasSkill && name === '灵食'
      ? {阶段: '未入门', 阶级: '未入门', 熟练度: 0, 成功率: 0, 次数: 0, 技法: []}
      : value.艺业[name];
    if (!row || typeof row !== 'object' || Array.isArray(row)) return null;
    const rank = value.schemaVersion === 1 ? row.阶段 : row.阶级;
    if (rank !== undefined && typeof rank !== 'string') return null;
    if (!validTextList(row.技法, 20, 80)) return null;
    const proficiency = Number(row.熟练度);
    if (!Number.isInteger(proficiency) || proficiency < 0 || proficiency > 100) return null;
    const successRate = value.schemaVersion === 1 ? 0 : Number(row.成功率);
    const count = value.schemaVersion === 1 ? 0 : Number(row.次数);
    if (!Number.isFinite(successRate) || successRate < 0 || successRate > 100 || !Number.isFinite(count) || count < 0) return null;
    skills[name] = {
      阶级: normalizeRank(rank),
      熟练度: proficiency,
      成功率: successRate,
      次数: count,
      技法: Array.isArray(row.技法) ? row.技法.slice(0, 20).map(item => text(item, 80)).filter(Boolean) : [],
    };
  }
  if (!Array.isArray(value.委托) || value.委托.length > MAX_ORDERS) return null;
  const orderIds = new Set();
  const orders = [];
  for (const row of value.委托) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) return null;
    if (!validTextList(row.所需条件, 8, 100) || !validTextList(row.缺少条件, 8, 100)) return null;
    const id = text(row.id, 48);
    if (!id || orderIds.has(id) || !ALLOWED_ORDER_STATES.includes(row.状态)) return null;
    orderIds.add(id);
    orders.push({
      id,
      名称:text(row.名称,80) || '未命名委托',
      委托人:text(row.委托人,80) || '未说明',
      缘由:text(row.缘由,180) || '未说明',
      艺业:ALL_PROFESSIONS.includes(row.艺业) ? row.艺业 : '未指定',
      要求:text(row.要求,240) || '待补充',
      难度:text(row.难度,40) || '未说明',
      所需条件:textList(row.所需条件,8,100),
      缺少条件:textList(row.缺少条件,8,100),
      期限:text(row.期限,80) || '无明确期限',
      报酬说明:text(row.报酬说明,160) || '未说明',
      失败代价:text(row.失败代价,160) || '未说明',
      当前进展:text(row.当前进展,200) || '待接取',
      状态:row.状态,
    });
  }
  if (!Array.isArray(value.履历) || value.履历.length > 60) return null;
  const history = value.履历.slice(-60).map(row => {
    if (!row || typeof row !== 'object' || Array.isArray(row)) return null;
    return {标题:text(row.标题,80) || '修习记录', 摘要:text(row.摘要,240)};
  });
  if (history.some(row => !row)) return null;
  const spirits = value.schemaVersion >= 4 ? value.器灵档案 : [];
  const attempts = value.schemaVersion >= 4 ? value.器灵尝试 : [];
  if (!Array.isArray(spirits) || spirits.length > 80 || !Array.isArray(attempts) || attempts.length > 120) return null;
  const allowedSpiritKinds = ['孕育新灵','已有器灵'];
  const allowedIncubation = ['无明确迹象','灵性留痕','灵性渐聚','出现回应','器灵初醒'];
  const itemIds = new Set();
  const spiritRecords = spirits.map(row => {
    if (!row || typeof row !== 'object' || Array.isArray(row)) return null;
    const id = text(row.id,48);
    if (!id || itemIds.has(id) || !allowedSpiritKinds.includes(row.类型)) return null;
    itemIds.add(id);
    if (row.类型 === '孕育新灵' && !allowedIncubation.includes(row.阶段)) return null;
    return {id,器物名称:text(row.器物名称,80) || '未命名器物',类型:row.类型,阶段:text(row.阶段,40) || (row.类型 === '孕育新灵' ? '无明确迹象' : '尚未确认'),器灵名称:text(row.器灵名称,60),器灵简述:text(row.器灵简述,240),关系状态:text(row.关系状态,80),已确认迹象:text(row.已确认迹象,240)};
  });
  if (spiritRecords.some(row => !row)) return null;
  const attemptIds = new Set();
  const spiritHistory = attempts.map(row => {
    if (!row || typeof row !== 'object' || Array.isArray(row)) return null;
    const id = text(row.id,64);
    if (!id || attemptIds.has(id) || !itemIds.has(text(row.器物编号,48))) return null;
    attemptIds.add(id);
    const result = text(row.结果,240);
    if (!result) return null;
    return {id,器物编号:text(row.器物编号,48),操作:text(row.操作,40) || '未说明',契机:text(row.契机,160),结果,后果:text(row.后果,240)};
  });
  if (spiritHistory.some(row => !row)) return null;
  return {schemaVersion:4, revision:value.revision, 艺业:skills, 委托:orders, 履历:history, 器灵档案:spiritRecords, 器灵尝试:spiritHistory};
}

function notify(message, kind = 'info') {
  const fn = globalThis.toastr?.[kind];
  if (typeof fn === 'function') fn(message, '《道渊》百艺');
  else console.info(`[《道渊》百艺] ${message}`);
}

async function ensureState() {
  const variables = api.getVariables({type:'chat'}) ?? {};
  const current = variables[MODULE_KEY];
  const cleaned = cleanState(current);
  if (cleaned) {
    if (current.schemaVersion !== 4 || !Object.prototype.hasOwnProperty.call(current.艺业, '灵食')) {
      const migrated = {...cleaned, revision:current.revision};
      await api.insertOrAssignVariables({[MODULE_KEY]:migrated},{type:'chat'});
      return migrated;
    }
    return current;
  }
  if (current !== undefined) throw new Error('existing 百艺 state is malformed; refusing to replace it');
  const initial = defaultState();
  await api.insertVariables({[MODULE_KEY]:initial},{type:'chat'});
  return initial;
}

function makePanelMessage() {
  return `<baiyi_panel>\n\`\`\`html\n${PANEL_HTML}\n\`\`\`\n</baiyi_panel>`;
}

async function openPanel() {
  const missing = requireCapabilities();
  if (missing.length) {
    notify(`缺少酒馆助手接口：${missing.join(', ')}`, 'warning');
    return;
  }
  try { await ensureState(); }
  catch (error) { notify(`百艺记录无法读取，未覆盖现有数据：${error.message}`, 'warning'); return; }
  const vars = api.getVariables({type:'chat'}) ?? {};
  const priorId = vars[UI_KEY]?.panelMessageId;
  const panelMessage = makePanelMessage();
  if (Number.isInteger(priorId) && api.getChatMessages(priorId)?.length) {
    await api.setChatMessages([{message_id:priorId,message:panelMessage}],{refresh:'affected'});
  } else {
    await api.createChatMessages([{role:'assistant',message:panelMessage}]);
    const messageId = api.getLastMessageId();
    await api.insertOrAssignVariables({[UI_KEY]:{panelMessageId:messageId}},{type:'chat'});
  }
}

function parseUpdate(raw) {
  const matches = [...raw.matchAll(new RegExp(`<${MODULE_TAG}>([\\s\\S]*?)<\\/${MODULE_TAG}>`, 'gi'))];
  if (matches.length !== 1) return null;
  try { return JSON.parse(matches[0][1].trim()); } catch { return null; }
}

function commissionChangesAllowed(current, next, pending) {
  const before = new Map(current.委托.map(order => [order.id, order]));
  const after = new Map(next.委托.map(order => [order.id, order]));
  // Keep every record in the ledger so completed work cannot be replayed as a fresh order.
  for (const order of before.values()) if (!after.has(order.id)) return false;
  const action = pending.action ?? {};
  const kind = action.类型;
  const targetId = action.委托编号;
  const additions = [...after.keys()].filter(id => !before.has(id));
  if (kind === '寻觅委托') {
    if (additions.length > 1 || additions.some(id => after.get(id).状态 !== '待接取')) return false;
  } else if (additions.length) return false;

  const terminal = new Set(['已完成', '已失败', '已放弃', '已拒绝']);
  const transitions = {
    待接取: new Set(['待接取', '进行中', '已失败', '已放弃', '已拒绝']),
    进行中: new Set(['进行中', '待交付', '已完成', '已失败', '已放弃']),
    待交付: new Set(['待交付', '进行中', '已完成', '已失败', '已放弃']),
  };
  for (const [id, oldOrder] of before) {
    const updated = after.get(id);
    if (terminal.has(oldOrder.状态) && oldOrder.状态 !== updated.状态) return false;
    if (oldOrder.状态 !== updated.状态 && id !== targetId) return false;
    if (!transitions[oldOrder.状态]?.has(updated.状态)) return false;
    if (id !== targetId || oldOrder.状态 === updated.状态) continue;
    const allowedByAction = {
      接取委托: new Set(['进行中']),
      议价委托: new Set(['进行中']),
      拒绝委托: new Set(['已拒绝']),
      推进委托: new Set(['待交付', '已失败']),
      交付委托: new Set(['已完成', '进行中', '待交付', '已失败']),
      放弃委托: new Set(['已放弃']),
    }[kind];
    if (!allowedByAction?.has(updated.状态)) return false;
  }
  if (targetId && !before.has(targetId)) return false;
  return true;
}

function spiritChangesAllowed(current, next, pending) {
  const oldItems = new Map(current.器灵档案.map(row => [row.id,row]));
  const newItems = new Map(next.器灵档案.map(row => [row.id,row]));
  for (const id of oldItems.keys()) if (!newItems.has(id)) return false;
  const action = pending.action ?? {};
  const intent = action.器灵意向;
  const oldAttempts = current.器灵尝试;
  const newAttempts = next.器灵尝试;
  if (!intent) return JSON.stringify(current.器灵档案) === JSON.stringify(next.器灵档案) && JSON.stringify(oldAttempts) === JSON.stringify(newAttempts);
  if (newAttempts.length < oldAttempts.length || newAttempts.length > oldAttempts.length + 1) return false;
  if (oldAttempts.some((row,index) => JSON.stringify(row) !== JSON.stringify(newAttempts[index]))) return false;
  if (newAttempts.length === oldAttempts.length) {
    return oldItems.size === newItems.size && [...oldItems.keys()].every(id => JSON.stringify(oldItems.get(id)) === JSON.stringify(newItems.get(id)));
  }
  const addedAttempt = newAttempts.at(-1);
  if (addedAttempt.器物编号 !== intent.记录编号 || addedAttempt.操作 !== intent.操作) return false;
  if (newItems.size > oldItems.size + 1) return false;
  for (const id of newItems.keys()) if (!oldItems.has(id) && id !== intent.记录编号) return false;
  for (const [id,oldRow] of oldItems) {
    if (id !== intent.记录编号 && JSON.stringify(oldRow) !== JSON.stringify(newItems.get(id))) return false;
  }
  const target = newItems.get(intent.记录编号);
  if (!target || target.器物名称 !== intent.器物名称 || target.类型 !== intent.类型) return false;
  const previous = oldItems.get(intent.记录编号);
  if (previous && previous.类型 !== target.类型) return false;
  if (previous?.类型 === '孕育新灵') {
    const stages = ['无明确迹象','灵性留痕','灵性渐聚','出现回应','器灵初醒'];
    if (stages.indexOf(target.阶段) < stages.indexOf(previous.阶段) || stages.indexOf(target.阶段) > stages.indexOf(previous.阶段) + 1) return false;
  }
  return true;
}

async function acceptAssistantUpdate(messageId) {
  if (!Number.isInteger(messageId)) return;
  const rows = api.getChatMessages(messageId,{role:'assistant'});
  const message = rows?.[0]?.message;
  if (typeof message !== 'string' || !message.includes(`<${MODULE_TAG}>`)) return;
  const update = parseUpdate(message);
  const variables = api.getVariables({type:'chat'}) ?? {};
  const pending = variables[PENDING_KEY];
  const current = cleanState(variables[MODULE_KEY]);
  if (!update || !pending || !current) {
    notify('收到百艺状态块，但缺少有效待处理行动或当前记录；没有写入。', 'warning');
    return;
  }
  if (update.actionId !== pending.actionId || update.expectedRevision !== pending.expectedRevision || pending.expectedRevision !== current.revision || update.revision !== current.revision + 1) {
    notify('百艺状态版本或行动编号不匹配；没有覆盖当前记录。', 'warning');
    return;
  }
  const next = cleanState(update.state);
  if (update.state?.schemaVersion !== 4 || !next || next.revision !== current.revision + 1) {
    notify('百艺状态结构不合法；没有写入。', 'warning');
    return;
  }
  if (!commissionChangesAllowed(current, next, pending)) {
    notify('委托变化与本次玩家行动不匹配，或试图删除/重开既有委托；没有写入。', 'warning');
    return;
  }
  if (!spiritChangesAllowed(current, next, pending)) {
    notify('器灵档案变化与本次玩家意向不匹配，或试图删除/改写既有尝试记录；没有写入。', 'warning');
    return;
  }
  await api.insertOrAssignVariables({[MODULE_KEY]:next},{type:'chat'});
  await api.deleteVariable(PENDING_KEY,{type:'chat'});
  notify('百艺记录已结算并保存。', 'success');
}

const missing = requireCapabilities();
if (missing.length) {
  notify(`百艺组件未启动，缺少：${missing.join(', ')}`, 'warning');
} else {
  api.eventOn(api.getButtonEvent(BUTTON_NAME), openPanel);
  if (!globalThis.tavern_events?.MESSAGE_RECEIVED) {
    notify('当前酒馆助手没有暴露 MESSAGE_RECEIVED；状态自动同步不可用。', 'warning');
  } else {
    api.eventOn(globalThis.tavern_events.MESSAGE_RECEIVED, acceptAssistantUpdate);
  }
}

(() => {
  const url = new URL(location.href);
  const focusedWorkbench = url.pathname === '/alchemy-workbench' || url.pathname === '/alchemy-workbench.html' || url.searchParams.get('view') === 'practice';
  if (!focusedWorkbench) return;

  const practiceTab = document.querySelector('[data-tab="practice"]');
  if (!practiceTab) return;
  practiceTab.click();

  const profession = url.searchParams.get('craft') || '炼丹';
  const selector = document.querySelector('[data-profession]');
  if (selector && [...selector.options].some(option => option.value === profession)) {
    selector.value = profession;
    selector.dispatchEvent(new Event('change', { bubbles: true }));
  }

  document.querySelector('[data-view="practice"]')?.scrollIntoView({ block: 'start' });
})();

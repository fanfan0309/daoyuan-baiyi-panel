import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const root = dirname(fileURLToPath(import.meta.url));
const sourceRoot = join(root, '..');

async function renderPreview() {
  const [shell, panelTemplate, practiceTools] = await Promise.all([
    readFile(join(root, 'index.html'), 'utf8'),
    readFile(join(sourceRoot, 'src', 'panel.html'), 'utf8'),
    readFile(join(sourceRoot, 'src', 'practice-tools.js'), 'utf8'),
  ]);
  if (shell.split('__PANEL_SOURCE__').length !== 2) throw new Error('Preview shell must contain exactly one panel source marker');
  if (panelTemplate.split('__PRACTICE_TOOL_SCHEMA__').length !== 2) throw new Error('Panel source is missing the shared practice-tool schema marker');
  const panel = panelTemplate.replace('__PRACTICE_TOOL_SCHEMA__', practiceTools);
  return shell.replace('__PANEL_SOURCE__', panel);
}

const previewPort = Number(process.env.DY_PREVIEW_PORT) || 8765;

createServer(async (request, response) => {
  try {
    const url = new URL(request.url ?? '/', 'http://127.0.0.1');
    if (url.pathname === '/food-workflow' || url.pathname === '/food-workflow.html') {
      response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      response.end(await readFile(join(root, 'food-workflow.html'), 'utf8'));
      return;
    }
    if (url.pathname === '/alchemy-workbench' || url.pathname === '/alchemy-workbench.html') {
      response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      response.end(await renderPreview());
      return;
    }
    if (url.pathname === '/focus-practice.js') {
      response.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8', 'cache-control': 'no-store' });
      response.end(await readFile(join(root, 'focus-practice.js')));
      return;
    }
    if (url.pathname === '/alchemy-workshop.png') {
      response.writeHead(200, { 'content-type': 'image/png', 'cache-control': 'public, max-age=3600' });
      response.end(await readFile(join(root, 'alchemy-workshop.png')));
      return;
    }
    const artMatch = url.pathname.match(/^\/art\/(alchemy|refining|talisman|formation|spiritplant|beast|puppet|medicine|spiritfood)\.webp$/);
    if (artMatch) {
      response.writeHead(200, { 'content-type': 'image/webp', 'cache-control': 'public, max-age=3600' });
      response.end(await readFile(join(root, 'art', `${artMatch[1]}.webp`)));
      return;
    }
    if (url.pathname === '/mock-runtime.js') {
      response.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8', 'cache-control': 'no-store' });
      response.end(await readFile(join(root, 'mock-runtime.js')));
      return;
    }
    response.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
    response.end(await renderPreview());
  } catch (error) {
    response.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
    response.end(`Preview build failed: ${error.message}`);
  }
}).listen(previewPort, '127.0.0.1');

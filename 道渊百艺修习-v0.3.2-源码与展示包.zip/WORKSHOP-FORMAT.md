# 《道渊工坊》导入路径核对

## 本任务实际采用的路径

用户提供的创作中心截图显示：在草稿的“内容条目”页面有“导入 Tavern JSON”按钮。当前目标是把百艺条目导入用户自己的现有草稿，不是创建公共发行物、签名 Dymod 或替换《道渊》原角色卡。

截图中的导入器提示它只接受 SillyTavern 导出的世界书或 Regex 文件。此前错误地把两类数据包进完整 Character Card V3 外壳；用户实测后，导入器明确拒绝了这种顶层结构。

现改为按入口可识别的标准形状分开提供：`dist/给使用者的导入文件/百艺修习-TavernJSON导入.json` 是一份 SillyTavern World Info 文件（`name` 与以 UID 为键的 `entries` 对象）；四条正则各自作为单条 Regex JSON 文件。请先追加世界书，再逐个追加四条正则。Tavern Helper 面板脚本仍需在脚本库中单独导入。

本地结构检查可以证明外层符合 SillyTavern World Info/Regex 文件形状，不能替代用户工坊导入预览的确认；导入预览若显示无法识别或条数为 0，应取消，不要确认写入。

## 与 Dymod 发行的区别

此前只读检查 `https://cdn.daoyuan.mayuworld.com/scripts/prod/latest/daoyuan-workshop.min.js` 及其 controller 得知：工坊的 `.dymod` 公共发行路径包含发行身份、条目清单、哈希和可信签名校验。这些约束属于可分发/安装的发行物路径，与截图中的“导入 Tavern JSON”草稿入口不是一回事。

本项目不创建或发布 Dymod、不申请包身份、不连接账号，也不需要为你的草稿导入伪造签名或 Registry 哈希。此前产生的 `.dymod` 条目候选与作者源 ZIP 不再是本任务交付入口；请使用上面的独立 Tavern JSON 文件。

## 参考结构依据

世界书文件采用 SillyTavern World Info 导出形状，正则文件采用 SillyTavern 单条 Regex 导出形状。完整角色卡 V3 的 `spec` 外壳并不是这个导入入口接受的文件类型。

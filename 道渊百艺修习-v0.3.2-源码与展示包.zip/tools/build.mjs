import { createHash } from 'node:crypto';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const dist = resolve(root, 'dist');
const withinRoot = path => path === root || path.startsWith(root + sep);
if (!withinRoot(dist)) throw new Error('Output escaped the source module root');

const read = name => readFile(join(root, name), 'utf8');
const practiceTools = await read('src/practice-tools.js');
const panelTemplate = await read('src/panel.html');
if (panelTemplate.split('__PRACTICE_TOOL_SCHEMA__').length !== 2 || practiceTools.split('const craftTools=').length !== 2) throw new Error('Shared practice-tool schema marker is missing');
const panel = panelTemplate.replace('__PRACTICE_TOOL_SCHEMA__', practiceTools);
const runtimeTemplate = await read('src/helper-runtime.js');
const regex = JSON.parse(await read('src/regex.json'));
const worldbook = await read('src/worldbook.md');
const worldbookNormalized = worldbook.replace(/\r\n?/g, '\n').normalize('NFC');
const contract = JSON.parse(await read('module-contract.json'));
const previewShell = await read('preview/index.html');
const previewMock = await read('preview/mock-runtime.js');
const previewFocus = await read('preview/focus-practice.js');
if (previewShell.split('__PANEL_SOURCE__').length !== 2 || !previewShell.includes('/mock-runtime.js') || !previewShell.includes('/focus-practice.js')) throw new Error('Preview shell is not wired to the source panel, mock runtime, and practice focus helper');
new Function(previewMock);
new Function(previewFocus);

const marker = '__PANEL_HTML_JSON__';
if (runtimeTemplate.split(marker).length !== 2) throw new Error('Expected one panel template marker');
const runtime = runtimeTemplate.replace(marker, JSON.stringify(panel));
if (!runtime.includes('data-dyb-root') || !runtime.includes('tavern_events.MESSAGE_RECEIVED')) {
  throw new Error('Helper runtime is missing required panel or sync hooks');
}
if (regex.length !== 4 || regex.some(item => !item.id || !item.findRegex)) throw new Error('Unexpected regex component set');
const requiredPanelTokens = ['炼丹','炼器','制符','布阵','灵植','御兽','傀儡','医修','灵食','复盘','寻师/访迹','data-order-filter','data-order-action','填入输入框','stat_data?.主角','暂不可读取','核心卡储物袋数据暂不可读取','核心卡储物袋当前为空','data-collapse-toggle','aria-expanded','成功率','记录','schemaVersion:4','data-spirit-toggle','器灵档案','器灵尝试','炼器四阶'];
const missingPanelTokens = requiredPanelTokens.filter(token => !panel.includes(token));
if (missingPanelTokens.length) throw new Error(`Panel is missing expected DLC content: ${missingPanelTokens.join(', ')}`);
const requiredRuleTokens = ['研习、演练、实作、复盘、寻师/访迹','待接取','待交付','已放弃','已拒绝','灵食','成功时增加 20–30','失败时熟练度增加 1–5','原卡没有规定固定公式','一阶、二阶、三阶','v1/v2/v3→v4','器灵','灵汐','委托记录不得从账簿删除'];
const missingRuleTokens = requiredRuleTokens.filter(token => !worldbook.includes(token));
if (missingRuleTokens.length) throw new Error(`Worldbook rules are missing expected content: ${missingRuleTokens.join(', ')}`);
if (runtime.includes('replaceMvuData') || runtime.includes('updateVariablesWith')) throw new Error('DLC runtime must not write core MVU data');
new Function(runtime); // Parse the completed helper script without executing it.
const panelScript = panel.match(/<script>([\s\S]*?)<\/script>/i)?.[1];
if (!panelScript) throw new Error('Panel interaction script is missing');
new Function(panelScript); // Parse panel-side interaction code without executing it.
for (const item of regex) new RegExp(item.findRegex.slice(1, item.findRegex.lastIndexOf('/')), item.findRegex.slice(item.findRegex.lastIndexOf('/') + 1));

await mkdir(dist, { recursive: true });
const helperOut = join(dist, 'helper-script-component');
const regexOut = join(dist, 'character-regex-component');
const workshopSourceOut = join(dist, 'dao-yuan-tavern-import-source');
const handoffOut = join(dist, '给使用者的导入文件');
await mkdir(helperOut, { recursive: true });
await mkdir(regexOut, { recursive: true });
await mkdir(workshopSourceOut, { recursive: true });
await mkdir(handoffOut, { recursive: true });
const helperScript = {
  type: 'script',
  enabled: true,
  name: '《道渊》百艺修习面板',
  id: '2e0ce1fd-d61e-438d-8b40-fca1b3c9df2e',
  content: runtime,
  info: '《道渊工坊·百艺修习》DLC。按钮打开个人百艺面板；动作确认只填入酒馆输入框，由玩家检查后自行发送。要求支持消息渲染器、脚本按钮、聊天变量和 MESSAGE_RECEIVED 的 Tavern Helper。原卡 MVU 炼丹/炼器/储物袋仅供读取，不在此脚本中写入。',
  button: { enabled: true, buttons: [{ name: '百艺面板', visible: true }] },
  data: {},
  export_with: { data: true, button: true },
};

async function writeComponentSet(directory, kind, artifacts) {
  const manifestArtifacts = [];
  for (const { name, value } of artifacts) {
    const content = JSON.stringify(value, null, 2) + '\n';
    const file = join(directory, name);
    await writeFile(file, content, 'utf8');
    const bytes = Buffer.from(content, 'utf8');
    manifestArtifacts.push({
      relativePath: name,
      id: value.id,
      kind,
      sha256: createHash('sha256').update(bytes).digest('hex'),
    });
  }
  const manifest = { schemaVersion: 1, deliveryMode: 'component', kind, artifacts: manifestArtifacts };
  await writeFile(join(directory, 'component-update-manifest.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8');
}

await writeComponentSet(helperOut, 'helper-script', [{ name: 'baiyi-helper.script.json', value: helperScript }]);
await writeComponentSet(regexOut, 'regex', regex.map((value, index) => ({ name: `baiyi-${index + 1}.regex.json`, value })));
await writeFile(join(dist, 'worldbook.md'), worldbook, 'utf8');
await writeFile(join(dist, 'module-contract.json'), JSON.stringify(contract, null, 2) + '\n', 'utf8');
await writeFile(join(dist, 'panel.source.html'), panel, 'utf8');
await writeFile(join(dist, '原卡边界核对.md'), await read('docs/原卡边界核对.md'), 'utf8');

const worldbookEntry = {
  id: 356,
  keys: ['【百艺行动', '百艺修习', '百艺面板', '寻觅委托', '接取委托', '交付委托', '制符', '布阵', '灵植', '御兽', '傀儡', '医修', '灵食'],
  secondary_keys: [],
  comment: '百艺修习规则',
  content: worldbookNormalized,
  constant: false,
  selective: false,
  insertion_order: 356,
  enabled: true,
  position: 'after_char',
  use_regex: false,
  extensions: {
    position: 1,
    exclude_recursion: true,
    display_index: 356,
    probability: 100,
    useProbability: true,
    depth: 4,
    selectiveLogic: 0,
    outlet_name: '',
    group: '',
    group_override: false,
    group_weight: 100,
    prevent_recursion: true,
    delay_until_recursion: false,
    scan_depth: null,
    match_whole_words: null,
    use_group_scoring: false,
    case_sensitive: null,
    automation_id: '',
    role: 0,
    vectorized: false,
    sticky: 0,
    cooldown: 0,
    delay: 0,
    match_persona_description: false,
    match_character_description: false,
    match_character_personality: false,
    match_character_depth_prompt: false,
    match_scenario: false,
    match_creator_notes: false,
    triggers: [],
    ignore_budget: false,
  },
};
const stWorldInfoEntry = {
  uid: worldbookEntry.id,
  key: worldbookEntry.keys,
  keysecondary: worldbookEntry.secondary_keys,
  comment: worldbookEntry.comment,
  content: worldbookEntry.content,
  constant: worldbookEntry.constant,
  vectorized: worldbookEntry.extensions.vectorized,
  selective: worldbookEntry.selective,
  selectiveLogic: worldbookEntry.extensions.selectiveLogic,
  addMemo: Boolean(worldbookEntry.comment),
  order: worldbookEntry.insertion_order,
  position: worldbookEntry.extensions.position,
  disable: !worldbookEntry.enabled,
  displayIndex: worldbookEntry.extensions.display_index,
  ignoreBudget: worldbookEntry.extensions.ignore_budget,
  excludeRecursion: worldbookEntry.extensions.exclude_recursion,
  preventRecursion: worldbookEntry.extensions.prevent_recursion,
  matchPersonaDescription: worldbookEntry.extensions.match_persona_description,
  matchCharacterDescription: worldbookEntry.extensions.match_character_description,
  matchCharacterPersonality: worldbookEntry.extensions.match_character_personality,
  matchCharacterDepthPrompt: worldbookEntry.extensions.match_character_depth_prompt,
  matchScenario: worldbookEntry.extensions.match_scenario,
  matchCreatorNotes: worldbookEntry.extensions.match_creator_notes,
  delayUntilRecursion: worldbookEntry.extensions.delay_until_recursion,
  probability: worldbookEntry.extensions.probability,
  useProbability: worldbookEntry.extensions.useProbability,
  depth: worldbookEntry.extensions.depth,
  outletName: worldbookEntry.extensions.outlet_name,
  group: worldbookEntry.extensions.group,
  groupOverride: worldbookEntry.extensions.group_override,
  groupWeight: worldbookEntry.extensions.group_weight,
  scanDepth: worldbookEntry.extensions.scan_depth,
  caseSensitive: worldbookEntry.extensions.case_sensitive,
  matchWholeWords: worldbookEntry.extensions.match_whole_words,
  useGroupScoring: worldbookEntry.extensions.use_group_scoring,
  automationId: worldbookEntry.extensions.automation_id,
  role: worldbookEntry.extensions.role,
  triggers: worldbookEntry.extensions.triggers,
};
for (const effect of ['sticky', 'cooldown', 'delay']) {
  const value = worldbookEntry.extensions[effect];
  if (typeof value === 'number' && value > 0) stWorldInfoEntry[effect] = value;
}
const stWorldbookImport = {
  name: '《道渊工坊》百艺修习内容候选',
  entries: { [worldbookEntry.id]: stWorldInfoEntry },
};
const regexArtifacts = regex.map((script, index) => ({
  name: `百艺修习-正则-${String(index + 1).padStart(2, '0')}.json`,
  value: script,
}));
const dlcReadme = `# 《道渊》百艺修习 · 工坊草稿导入文件\n\n工坊的“导入 Tavern JSON”入口接受的是 **SillyTavern 世界书文件或单条 Regex 导出文件**，不能导入完整角色卡 V3 外壳。请勿选择旧的整卡容器。\n\n## 导入到现有草稿\n\n1. 先导入 \`worldbook/百艺修习.worldbook.json\`，预览应识别为 1 条世界书。\n2. 选择“追加”，把 \`regex/\` 目录内的四个 JSON 文件逐个导入；每个预览应识别为 1 条正则。\n3. Tavern Helper 面板脚本是独立文件 \`tavern-helper/百艺修习.helper-script.json\`，在 Tavern Helper 脚本库中另行导入。\n\n若预览显示“无法识别”或条数为 0，请取消导入，不要确认写入。\n\n接取、议价、拒绝、推进、交付和放弃委托等操作都只会生成输入栏草稿，由玩家自行检查、编辑并发送。面板脚本不会随世界书或 Regex 文件导入。\n`;
const dlcFiles = [
  ['worldbook/百艺修习.worldbook.json', JSON.stringify(stWorldbookImport, null, 2) + '\n'],
  ...regexArtifacts.map(({ name, value }) => [`regex/${name}`, JSON.stringify(value, null, 2) + '\n']),
  ['tavern-helper/百艺修习.helper-script.json', JSON.stringify(helperScript, null, 2) + '\n'],
  ['说明.md', dlcReadme],
];
await rm(join(workshopSourceOut, '百艺修习-TavernJSON导入.json'), { force: true });
await rm(join(workshopSourceOut, 'regex', '百艺修习.regex.json'), { force: true });
for (const [relative, content] of dlcFiles) {
  const file = join(workshopSourceOut, relative);
  await mkdir(dirname(file), { recursive: true });
  await writeFile(file, content, 'utf8');
}
await writeFile(join(dist, '百艺修习-TavernJSON导入.json'), JSON.stringify(stWorldbookImport, null, 2) + '\n', 'utf8');
await writeFile(join(handoffOut, '百艺修习-TavernJSON导入.json'), JSON.stringify(stWorldbookImport, null, 2) + '\n', 'utf8');
for (const { name, value } of regexArtifacts) {
  await writeFile(join(handoffOut, name), JSON.stringify(value, null, 2) + '\n', 'utf8');
}
await writeFile(join(handoffOut, '百艺修习-TavernHelper面板脚本.json'), JSON.stringify(helperScript, null, 2) + '\n', 'utf8');
await writeFile(join(handoffOut, '导入顺序.md'), `# 《道渊》百艺修习 · 工坊草稿导入文件\n\n工坊的“导入 Tavern JSON”入口接受 SillyTavern 世界书或单条 Regex 文件，不接受完整角色卡 V3 外壳。\n\n1. 先导入 **百艺修习-TavernJSON导入.json**，预览应识别为 1 条世界书。\n2. 选择“追加”，再把 **百艺修习-正则-01.json** 至 **百艺修习-正则-04.json** 逐个导入；每个预览应识别为 1 条正则。\n3. **百艺修习-TavernHelper面板脚本.json** 需要在 Tavern Helper 脚本库中另行导入。\n\n预览中若只提示顶层 /name 是书籍元数据，以及正文将规范为 LF/NFC，这是信息提示：条目仍在 /entries/356，正文当前已是 LF 和 NFC。若显示无法识别、待导入条数为 0，或出现其他字段丢失提示，请取消并先检查文件。\n\n委托相关操作只填入输入栏草稿，由玩家自行检查并发送。\n`, 'utf8');
if (Object.keys(stWorldbookImport.entries).length !== 1 || Array.isArray(stWorldbookImport.entries) || stWorldInfoEntry.key[0] !== worldbookEntry.keys[0] || stWorldInfoEntry.content !== worldbookNormalized || stWorldInfoEntry.disable !== false) {
  throw new Error('DLC worldbook entry did not preserve the source rules or enabled state');
}
if ('extensions' in stWorldInfoEntry || !['sticky','cooldown','delay'].every(key => !(key in stWorldInfoEntry) || stWorldInfoEntry[key] > 0) || stWorldInfoEntry.content.includes('\r\n') || stWorldInfoEntry.content !== stWorldInfoEntry.content.normalize('NFC')) {
  throw new Error(`DLC worldbook import check failed: ${JSON.stringify({extensions: 'extensions' in stWorldInfoEntry, effects: ['sticky','cooldown','delay'].map(key => [key, stWorldInfoEntry[key]]), contentHasCRLF: stWorldInfoEntry.content.includes('\r\n'), contentIsNFC: stWorldInfoEntry.content === stWorldInfoEntry.content.normalize('NFC')})}`);
}
if (!Array.isArray(JSON.parse(JSON.stringify(regex))) || regex.length !== 4) throw new Error('DLC regex set is incomplete');
if ('spec' in stWorldbookImport || !stWorldbookImport.entries?.[worldbookEntry.id]?.key || !regexArtifacts.every(({ value }) => value?.id && value?.scriptName && value?.findRegex)) throw new Error('Creator Center import files are not native World Info / Regex exports');
const helperDownload = JSON.parse(JSON.stringify(helperScript));
if (helperDownload.type !== 'script' || !helperDownload.content || helperDownload.button?.buttons?.[0]?.name !== '百艺面板') {
  throw new Error('Manual Tavern Helper download is malformed');
}
const handoffTavernImport = JSON.parse(await readFile(join(handoffOut, '百艺修习-TavernJSON导入.json'), 'utf8'));
const handoffHelper = JSON.parse(await readFile(join(handoffOut, '百艺修习-TavernHelper面板脚本.json'), 'utf8'));
const handoffRegex = await Promise.all(regexArtifacts.map(({ name }) => readFile(join(handoffOut, name), 'utf8').then(JSON.parse)));
if (JSON.stringify(handoffTavernImport) !== JSON.stringify(stWorldbookImport) || JSON.stringify(handoffHelper) !== JSON.stringify(helperScript) || handoffRegex.some((script, index) => JSON.stringify(script) !== JSON.stringify(regex[index]))) {
  throw new Error('User handoff files do not match the canonical import artifacts');
}

const receipt = {};
for (const relative of [
  'helper-script-component/baiyi-helper.script.json',
  'helper-script-component/component-update-manifest.json',
  ...regex.map((_, index) => `character-regex-component/baiyi-${index + 1}.regex.json`),
  'character-regex-component/component-update-manifest.json',
  'worldbook.md',
  '百艺修习-TavernJSON导入.json',
  '给使用者的导入文件/百艺修习-TavernJSON导入.json',
  ...regexArtifacts.map(({ name }) => `给使用者的导入文件/${name}`),
  '给使用者的导入文件/百艺修习-TavernHelper面板脚本.json',
  '给使用者的导入文件/导入顺序.md',
  'dao-yuan-tavern-import-source/worldbook/百艺修习.worldbook.json',
  ...regexArtifacts.map(({ name }) => `dao-yuan-tavern-import-source/regex/${name}`),
  'dao-yuan-tavern-import-source/tavern-helper/百艺修习.helper-script.json',
  'dao-yuan-tavern-import-source/说明.md',
  'module-contract.json',
  'panel.source.html',
  '原卡边界核对.md',
]) {
  const bytes = await readFile(join(dist, relative));
  receipt[relative] = { bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') };
}
const sourceHashes = {};
for (const relative of ['src/helper-runtime.js','src/panel.html','src/worldbook.md','src/regex.json','module-contract.json','docs/原卡边界核对.md','DESIGN.md','README.md','TEST-HANDOFF.md','WORKSHOP-FORMAT.md','preview/index.html','preview/server.mjs','preview/mock-runtime.js','preview/focus-practice.js','tools/build.mjs','tools/regex-fixtures.json']) {
  const bytes = await readFile(join(root, relative));
  sourceHashes[relative] = createHash('sha256').update(bytes).digest('hex');
}
await writeFile(join(dist, 'validation-report.json'), JSON.stringify({
  schemaVersion: 1,
  scope: 'static-source-and-component-build',
  checks: [
    {id:'panel-content-contract',result:'passed',details:requiredPanelTokens},
    {id:'core-field-read-fallback',result:'passed',details:{path:'message variables → stat_data.主角',unreadable:'显示暂不可读取，不推断为无记录或空库存',coreStateWrite:false}},
    {id:'worldbook-content-contract',result:'passed',details:requiredRuleTokens},
    {id:'local-worldbook-shape',result:'passed',details:{entries:Object.keys(stWorldbookImport.entries).length,format:'SillyTavern World Info export',entryKey:'key',sourceParity:stWorldInfoEntry.content === worldbookNormalized,workshopWarningsAddressed:{redundantExtensionsRemoved:!('extensions' in stWorldInfoEntry),nonpositiveTimedEffectsOmitted:['sticky','cooldown','delay'].every(key=>!(key in stWorldInfoEntry)||stWorldInfoEntry[key]>0),contentAlreadyLF:!stWorldInfoEntry.content.includes('\r\n'),contentAlreadyNFC:stWorldInfoEntry.content===stWorldInfoEntry.content.normalize('NFC')}}},
    {id:'local-regex-shape',result:'passed',details:{count:regex.length,format:'SillyTavern character-local RegexScriptData; one standalone script object per import file'}},
    {id:'creator-center-tavern-json-import',result:'passed',details:{worldbookEntries:Object.keys(stWorldbookImport.entries).length,regexFiles:regexArtifacts.length,regexScriptsPerFile:1,cardEnvelopeIncluded:false,helperScriptSeparate:true,sourceParity:true}},
    {id:'manual-helper-download-shape',result:'passed',details:{type:helperScript.type,button:helperScript.button.buttons[0].name}},
    {id:'user-handoff-file-parity',result:'passed',details:{worldbookMatchesCanonical:true,regexMatchesCanonical:handoffRegex.length,helperMatchesCanonical:true,helperSeparate:true}},
    {id:'helper-script-parse',result:'passed'},
    {id:'panel-script-parse',result:'passed'},
    {id:'large-scene-preview-source-parity',result:'passed',details:'The /alchemy-workbench preview route renders preview/index.html with the same src/panel.html and shared practice-tools.js used by the embedded panel.'},
    {id:'regex-pattern-parse',result:'passed',count:regex.length},
    {id:'core-mvu-write-boundary',result:'passed',details:'No MVU writer call is included in the DLC runtime.'},
  ],
  realHostAcceptance: 'pending-user-test',
}, null, 2) + '\n', 'utf8');
const validationBytes = await readFile(join(dist, 'validation-report.json'));
receipt['validation-report.json'] = {bytes:validationBytes.length, sha256:createHash('sha256').update(validationBytes).digest('hex')};
await writeFile(join(dist, 'build-receipt.json'), JSON.stringify({ schemaVersion: 1, state: 'creator-center-tavern-json-import-source', files: receipt, sourceHashes }, null, 2) + '\n', 'utf8');
console.log(JSON.stringify({ outputDirectory: dist, files: Object.keys(receipt) }, null, 2));

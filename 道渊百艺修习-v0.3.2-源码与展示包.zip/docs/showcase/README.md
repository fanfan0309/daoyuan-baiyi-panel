# 《道渊》百艺修习展示图

以下图片取自本地静态预览，数据为虚构演示数据，用于展示面板内容与视觉风格；不代表已在真实酒馆环境完成验收。

## 总览

![百艺总览](showcase-overview.png)

## 技艺修习

![炼丹修习示例](showcase-study.png)

## 灵食修习

![灵食修习示例](showcase-food.png)

## 委托

![委托任务示例](showcase-commissions.png)

## 修习记录

![修习记录示例](showcase-records.png)
